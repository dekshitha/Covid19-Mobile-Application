package com.example.covidapp;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class VaccineActivity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vaccine4);
        getSupportActionBar().setTitle("VACCINE");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}