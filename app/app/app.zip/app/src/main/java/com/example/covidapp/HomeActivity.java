package com.example.covidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {
    Button btnTrack;
    SeekBar timer_sb;
    TextView timer_tv;
    Button start_btn;
    CountDownTimer countDownTimer;
    Boolean counterIsActive=false;
    Button call;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        btnTrack=(Button)findViewById(R.id.btntrack);
        call=(Button)findViewById(R.id.call);

        timer_sb=findViewById(R.id.timer_sb);
        timer_tv=findViewById(R.id.timer_tv);
        start_btn=findViewById(R.id.start_btn);
        timer_sb.setMax(30);
        timer_sb.setProgress(30);
        timer_sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                update(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        btnTrack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),TrackActivity.class);
                startActivity(intent);
            }
        });

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s= "1075";
                Intent callintent=new Intent(Intent.ACTION_CALL);
                callintent.setData(Uri.parse("tel:"+s));
                startActivity(callintent);
            }
        });
    }

    private void update(int progress){
        int minutes=progress/60;
        int seconds=progress % 60;
        String secondsFinal = "";
        if(seconds <= 9){
            secondsFinal="0" + seconds;
        }
        else{
            secondsFinal=""+seconds;
        }
        timer_sb.setProgress(progress);
        timer_tv.setText("" + minutes + ":" + secondsFinal);
    }

    public void start_timer(View view){
        if(counterIsActive == false) {
            counterIsActive = true;
            timer_sb.setEnabled(false);
            start_btn.setText("STOP");
            countDownTimer = new CountDownTimer(timer_sb.getProgress() * 1000, 1000) {
                @Override
                public void onTick(long millisUnitFinished) {
                    update((int) millisUnitFinished / 1000);
                }

                @Override
                public void onFinish() {
                    reset();


                }
            }.start();

        }
        else{
            reset();
        }
    }
    private void reset(){
        timer_tv.setText("0:30");
        timer_sb.setProgress(30);
        countDownTimer.cancel();
        start_btn.setText("START");
        timer_sb.setEnabled(true);
        counterIsActive=false;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(counterIsActive){
            countDownTimer.cancel();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(counterIsActive){
            countDownTimer.cancel();
        }
    }

    public void track(View view) {
        Intent intent=new Intent(getApplicationContext(),TrackActivity.class);
        startActivity(intent);

    }

    public void donate(View view) {
        String url="https://www.pmcares.gov.in";
        Intent intent=new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);

    }

    public void quiz_activity(View view) {
        Intent intent=new Intent(getApplicationContext(),quiz.class);
        startActivity(intent);
    }

    public void guidepg(View view) {
        Intent intent=new Intent(getApplicationContext(),GuideActivity.class);
        startActivity(intent);
    }

    public void vaccine(View view) {
        String url="https://www.cowin.gov.in";
        Intent intent=new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }

    public void vaccinepg(View view) {
        Intent intent=new Intent(getApplicationContext(),VaccineActivity.class);
        startActivity(intent);
    }
}