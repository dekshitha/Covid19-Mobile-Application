package com.example.covidapp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;


public class PrecautionsFragment extends Fragment {

    View v;
    RecyclerView rev;
    myadapter recadapter;

    public PrecautionsFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.precautions_fragment,container,false);
        return v;
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rev = (RecyclerView) view.findViewById(R.id.precview);
        rev.setLayoutManager(new LinearLayoutManager(getActivity()));

        recadapter = new myadapter(pdataqueue());
        rev.setAdapter(recadapter);
    }

    public ArrayList<Model> pdataqueue() {
        ArrayList<Model> pholder = new ArrayList<>();

        Model ob1 = new Model();
        ob1.setHeader("Clean");
        ob1.setDesc("Clean and disinfect frequently touched objects and surfaces");
        ob1.setImgname(R.drawable.clean);
        pholder.add(ob1);

        Model ob2 = new Model();
        ob2.setHeader("Cover");
        ob2.setDesc("Cover your sneeze or cough with a sleeve or tissue. Bin your tissue after use");
        ob2.setImgname(R.drawable.cover);
        pholder.add(ob2);

        Model ob3 = new Model();
        ob3.setHeader("Distance");
        ob3.setDesc("Avoid physical contact such as hugs or handshakes when greeting someone");
        ob3.setImgname(R.drawable.distance);
        pholder.add(ob3);

        Model ob4 = new Model();
        ob4.setHeader("Soap");
        ob4.setDesc("Wash your hands frequently with soap and water");
        ob4.setImgname(R.drawable.soap);
        pholder.add(ob4);

        Model ob5 = new Model();
        ob5.setHeader("Stay Home");
        ob5.setDesc("Stay Home if you feel ill");
        ob5.setImgname(R.drawable.hone);
        pholder.add(ob5);


        return pholder;

    }
}