package com.example.covidapp;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class VaccineActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vaccine2);
        getSupportActionBar().setTitle("VACCINE");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
}