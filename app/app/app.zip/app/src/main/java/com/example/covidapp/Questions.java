package com.example.covidapp;

import java.io.OptionalDataException;

public class Questions {

    public String mQuestions[] = {
            "Do you have any of the following pre-existing conditions? (Diabetes, heart problems, asthma, etc)",
            "Have you got in contact with covid affected person?",
            "Is there covid 19 cases in your surroundings? ",
            "Are you currently experiencing any of the covid 19 symptoms?",
            "Have you travelled in the past 14 days to any of the states? ",
            "Could you complete the breathing test?",
            "Do you experience fatigue often?",
            "Have you followed all guidelines and safety precautions ? ",
            "Have you visited any crowded place or used public transport ? ",
            "Have you vaccinated? "
    };
    private String mChoices[] [] = {
            {"YES","NO"},
            {"YES","NO"},
            {"YES","NO"},
            {"YES","NO"},
            {"YES","NO"},
            {"YES","NO"},
            {"YES","NO"},
            {"YES","NO"},
            {"YES","NO"},
            {"YES","NO"}
    };
    private String mCorrectAnswers[] = {"NO","NO","NO","NO","NO","YES","NO","YES","NO","YES",};

    public String getQuestion(int a) {
        String question = mQuestions[a];
        return question;
    }
    public String getChoice1(int a){
        String choice = mChoices[a][0];
        return choice;
    }
    public String getChoice2(int a) {
        String choice = mChoices[a][1];
        return choice;
    }

    public String getCorrectAnswer(int a)
    {
        String answer = mCorrectAnswers[a];
        return answer;
    }

}
