package com.example.covidapp;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class VaccineActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vaccine3);
        getSupportActionBar().setTitle("VACCINE");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
}