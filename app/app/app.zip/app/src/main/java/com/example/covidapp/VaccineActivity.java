package com.example.covidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

public class VaccineActivity extends AppCompatActivity {

    Button register;
    TextView textView;
    TextView textView1;
    TextView textView2;
    TextView textView3;
    YouTubePlayerView youTubePlayerView;
    YouTubePlayerView youTubePlayerView1;
    YouTubePlayerView youTubePlayerView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vaccine);

        register = findViewById(R.id.register);
        textView = findViewById(R.id.txt_view);
        textView1 = findViewById(R.id.txt_view1);
        textView2 = findViewById(R.id.txt_view2);
        textView3 = findViewById(R.id.txt_view3);
        youTubePlayerView = findViewById(R.id.youtube_player_view);
        youTubePlayerView1 = findViewById(R.id.youtube_player_view1);
        youTubePlayerView2 = findViewById(R.id.youtube_player_view2);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://selfregistration.cowin.gov.in/");
            }
        });

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(VaccineActivity.this,VaccineActivity2.class);
                startActivity(intent);

                Toast.makeText(VaccineActivity.this,"you clicked on text", Toast.LENGTH_LONG).show();
            }
        });
        textView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(VaccineActivity.this,VaccineActivity3.class);
                startActivity(intent);

                Toast.makeText(VaccineActivity.this,"you clicked on button", Toast.LENGTH_LONG).show();
            }
        });

        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(VaccineActivity.this,VaccineActivity4.class);
                startActivity(intent);

                Toast.makeText(VaccineActivity.this,"you clicked on button", Toast.LENGTH_LONG).show();
            }
        });

        textView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(VaccineActivity.this,VaccineActivity5.class);
                startActivity(intent);

                Toast.makeText(VaccineActivity.this,"you clicked on button", Toast.LENGTH_LONG).show();
            }
        });

        youTubePlayerView.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onApiChange(YouTubePlayer youTubePlayer) {
                super.onApiChange(youTubePlayer);

                String id  = "EF96sSZJGh4";
                youTubePlayer.loadVideo(id,0);
            }
        });

        youTubePlayerView1.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onApiChange(YouTubePlayer youTubePlayer) {
                super.onApiChange(youTubePlayer);

                String id  = "ceiKWJV72Y4";
                youTubePlayer.loadVideo(id,0);
            }
        });

        youTubePlayerView2.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onApiChange(YouTubePlayer youTubePlayer) {
                super.onApiChange(youTubePlayer);

                String id  = "ebW85J9V_s0";
                youTubePlayer.loadVideo(id,0);
            }
        });
    }

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }
}