package com.example.covidapp;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextClock;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class myviewHolder extends RecyclerView.ViewHolder {

    ImageView img;
    TextView title, des;

    public myviewHolder(@NonNull View itemView) {
        super(itemView);
        img = (ImageView)itemView.findViewById(R.id.imageCough);
        title = (TextView)itemView.findViewById(R.id.titleCough);
        des = (TextView)itemView.findViewById(R.id.descriptionCough);

    }
}
