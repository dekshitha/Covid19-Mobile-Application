package com.example.covidapp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class SymptomsFragment extends Fragment {

    View v;
    RecyclerView rev;
    myadapter recadapter;
    public SymptomsFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.symptoms_fragment,container,false);
        return v;
    }

    @Override
    public void onViewCreated(@NonNull @org.jetbrains.annotations.NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rev = (RecyclerView) view.findViewById(R.id.recview);
        rev.setLayoutManager(new LinearLayoutManager(getActivity()));

        recadapter = new myadapter(dataqueue());
        rev.setAdapter(recadapter);
    }

    public ArrayList<Model> dataqueue() {
        ArrayList<Model> holder = new ArrayList<>();

        Model ob1 = new Model();
        ob1.setHeader("Cough");
        ob1.setDesc("Coughing a lot for more than 1 hour. Dry cough");
        ob1.setImgname(R.drawable.cough);
        holder.add(ob1);

        Model ob2 = new Model();
        ob2.setHeader("Fever");
        ob2.setDesc("Temperature higher than 101degreeF that lasts for more than 2 days.");
        ob2.setImgname(R.drawable.fever);
        holder.add(ob2);

        Model ob3 = new Model();
        ob3.setHeader("Fatigue");
        ob3.setDesc("Feeling tired all the time and is not relieved by sleep or rest.");
        ob3.setImgname(R.drawable.fatigue);
        holder.add(ob3);

        Model ob4 = new Model();
        ob4.setHeader("Running Nose");
        ob4.setDesc("Running Nose because of cold for more than 2 days");
        ob4.setImgname(R.drawable.nose);
        holder.add(ob4);

        Model ob5 = new Model();
        ob5.setHeader("Sore Throat");
        ob5.setDesc("Throat soreness and irritation. Pain or scratchy sensation in the throat.");
        ob5.setImgname(R.drawable.sore_throat);
        holder.add(ob5);

        Model ob6 = new Model();
        ob6.setHeader("Headache");
        ob6.setDesc("Severe headache with loss of taste and smell.");
        ob6.setImgname(R.drawable.pain);
        holder.add(ob6);


        return holder;

    }
}
