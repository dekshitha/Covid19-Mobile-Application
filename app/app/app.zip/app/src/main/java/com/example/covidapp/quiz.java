package com.example.covidapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.Random;

public class quiz extends AppCompatActivity {
    Button answer1, answer2;

    TextView score, question;

    private Questions mQuestions = new Questions();
    private String mAnswer;
    private int mScore = 0;
    private int mQuestionsLength = mQuestions.mQuestions.length;
    public int i = 0;

    Random r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        r = new Random();

        answer1 = (Button) findViewById(R.id.answer1);
        answer2 = (Button) findViewById(R.id.answer2);


        question = (TextView) findViewById(R.id.question);

        if (i > 10) {
            BackToHomePage();
        } else {

            updateQuestion(i);
            answer1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (answer1.getText() == mAnswer) {
                        mScore++;
                        updateQuestion(i + 1);
                        i++;
                    } else if (answer1.getText() != mAnswer) {
                        updateQuestion(i + 1);
                        i++;
                    }

                }
            });

            answer2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (answer2.getText() == mAnswer) {
                        mScore++;
                        updateQuestion(i + 1);
                        i++;
                    } else if (answer2.getText() != mAnswer) {
                        updateQuestion(i + 1);
                        i++;
                    }


                }
            });


        }
    }

    private void updateQuestion(int num) {
        if (num >= 10) {
            BackToHomePage();
        } else {
            question.setText(mQuestions.getQuestion(num));
            answer1.setText(mQuestions.getChoice1(num));
            answer2.setText(mQuestions.getChoice2(num));


            mAnswer = mQuestions.getCorrectAnswer(num);
        }
    }

    private void BackToHomePage() {
        if (mScore >= 7) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(quiz.this);
            alertDialogBuilder.setMessage("Looks like you are Safe!")

                    .setCancelable(false)
                    .setPositiveButton("HOME",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                                    finish();

                                }
                            });

            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
        else if(mScore < 7){
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(quiz.this);
                alertDialogBuilder.setMessage("Please get tested. You may have few symptoms.")

                        .setCancelable(false)
                        .setPositiveButton("HOME",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                                        finish();

                                    }
                                });

                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
        }
    }

